#define ERROR_H

void checkError (const char* msg);




#include <GL/glew.h>
#include <GL/gl.h>

GLuint CreateShader (GLenum shadertype, const char* filename);
GLuint setProgram (int sid, ...);



